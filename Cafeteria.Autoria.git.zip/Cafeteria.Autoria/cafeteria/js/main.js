
import { buscarCafes } from './api.js';

async function iniciarSite() {

    const cafes = await buscarCafes();

    const root = document.getElementById('root');

    const titulo = document.createElement('h1');
    titulo.textContent = 'Cafeteria Autoria Web';
    titulo.className = 'text-center my-4';

    const container = document.createElement('div');
    container.className = 'container';

    const linha = document.createElement('div');
    linha.className = 'row g-4';

    cafes.forEach(cafe => {

        const coluna = document.createElement('div');
        coluna.className = 'col-12 col-md-6 col-lg-4';

        const card = document.createElement('div');
        card.className = 'card h-100';

        const imagem = document.createElement('img');
        imagem.src = cafe.image;
        imagem.alt = cafe.title;
        imagem.className = 'card-img-top';
        imagem.style.height = '220px';
        imagem.style.objectFit = 'cover';

        const corpo = document.createElement('div');
        corpo.className = 'card-body';

        const nome = document.createElement('h5');
        nome.className = 'card-title';
        nome.textContent = cafe.title;

        const descricao = document.createElement('p');
        descricao.className = 'card-text';
        descricao.textContent = cafe.description;


        const ingredientes = document.createElement('p');
        ingredientes.textContent =
            'Ingredientes: ' + cafe.ingredients.join(', ');

        const preco = document.createElement('p');
        preco.className = 'fw-bold';
        preco.textContent = cafe.price.toLocaleString('pt-BR', {
            style: 'currency',
            currency: 'BRL'
        });

        corpo.appendChild(nome);
        corpo.appendChild(descricao);
        corpo.appendChild(ingredientes);
        corpo.appendChild(preco);

        card.appendChild(imagem);
        card.appendChild(corpo);

        coluna.appendChild(card);
        linha.appendChild(coluna);

    });

    container.appendChild(linha);

    root.appendChild(titulo);
    root.appendChild(container);

}

iniciarSite();
